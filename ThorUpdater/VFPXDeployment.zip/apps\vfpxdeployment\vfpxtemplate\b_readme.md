@@@
The template for README.md in project BuildProcess folder
Placeholders will be replaced  once
\\\# {APPNAME}

Buildprocess for project {APPNAME}

This folder contains information to create the next deployment of this project to Thor.