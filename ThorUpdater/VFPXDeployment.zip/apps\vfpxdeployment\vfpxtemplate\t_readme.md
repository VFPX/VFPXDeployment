@@@
The template for README.md in project ThorUpdater folder
Placeholders will be replaced  once
\\\# {APPNAME}

ThorUpdater for project {APPNAME}

This folder contains the deployment of this project to be used by Thor.