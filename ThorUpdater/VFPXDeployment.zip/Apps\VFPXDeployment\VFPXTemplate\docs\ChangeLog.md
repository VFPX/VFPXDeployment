@@@ 
The following will be set on initial run:
{APPNAME}
{CVERSIONDATE}

Fill other placeholders
\\\# {APPNAME} Change list

{Abbreviated project description}

## Release History

### {Release date as YYYY-MM-DD}, Version {Version number}}

* {List of changes}

----
Last changed: {CVERSIONDATE}

![](./images/vfpxpoweredby_alternative.gif)