# {APPNAME}

ThorUpdater for project {APPNAME}

This folder contains the deployment of this project to be used by Thor.