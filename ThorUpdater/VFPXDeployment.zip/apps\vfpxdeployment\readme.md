# VFPX Deployment

InstalledFiles\Apps\VFPXDeployment

Templates for project VFPX Deployment

This folder and it's subfolder conatin templates to create the a VFPX/Thor project