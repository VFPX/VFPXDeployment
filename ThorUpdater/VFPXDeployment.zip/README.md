# VFPX Deployment

ThorUpdater for project VFPX Deployment

This folder contains the deployment of this project to be used by Thor.