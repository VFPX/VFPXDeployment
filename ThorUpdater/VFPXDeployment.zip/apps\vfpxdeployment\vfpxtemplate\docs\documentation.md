@@@ 
The following will be set on initial run:
{APPNAME}
{CVERSIONDATE}

Fill other placeholders
\\\# {APPNAME} Documentation

{Overview of documentation}

[Topic 1](topic1.md)

[Topic 2](topic2.md)

----
Last changed: {CVERSIONDATE}

![powered by VFPX](./images/vfpxpoweredby_alternative.gif "powered by VFPX")